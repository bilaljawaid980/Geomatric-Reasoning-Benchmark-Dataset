"""Central acceptance check: byte-diff returned and independently regenerated manifests."""
import argparse,csv,hashlib,json,re
from pathlib import Path,PureWindowsPath
from verify import assert_public,verify_integrity

def sha(p):assert_public(p);return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--received-dir',type=Path,required=True);p.add_argument('--regenerated-dir',type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parent;integrity=verify_integrity(root)
    for directory in [a.received_dir,a.regenerated_dir]:assert_public(directory)
    rp=a.received_dir/'phase_b_provenance.json';cp=a.regenerated_dir/'phase_b_provenance.json'
    assert_public(rp);assert_public(cp)
    received=json.loads(rp.read_text(encoding='utf-8'));central=json.loads(cp.read_text(encoding='utf-8'))
    for prov in [received,central]:
        if prov['scorer_sha256']!=integrity['construction_scorer']['sha256'] or prov['config_sha256']!=integrity['tolerance_configuration']['sha256'] or prov['pins_sha256']!=integrity['dependency_input_pins']['sha256']:raise SystemExit('Run rejected: scorer/config/pins provenance differs from issued package')
    if set(received['runs'])!=set(central['runs']):raise SystemExit('Run rejected: model/experiment sets differ')
    for identity,run in received['runs'].items():
        name=run['manifest_filename']
        if Path(name).name!=name or PureWindowsPath(name).drive or '\\' in name:raise SystemExit('Unsafe manifest filename')
        remote=a.received_dir/name;local=a.regenerated_dir/name
        assert_public(remote);assert_public(local)
        if sha(remote)!=run['manifest_sha256'] or sha(local)!=central['runs'][identity]['manifest_sha256']:raise SystemExit('Run rejected: manifest does not match its provenance hash')
        if remote.read_bytes()!=local.read_bytes():raise SystemExit('Run rejected: manifests differ; scorer/construction drift')
        for field in ['round1_response_sha256','round1_counts','arm_counts','manifest_rows','skipped']:
            if run[field]!=central['runs'][identity][field]:raise SystemExit('Run rejected: provenance differs: '+field)
        with remote.open(encoding='utf-8',newline='') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames!=['row_id','model','image_path','prompt_text']:raise SystemExit('Run rejected: nonminimal manifest schema')
            for row in reader:
                if not re.fullmatch(r'images/[a-z0-9_]+/[a-z0-9_]+\.png',row['image_path']):raise SystemExit('Run rejected: unsafe/nonrelative image path')
    print(json.dumps({'model_experiment_runs_checked':len(received['runs']),'byte_differences':0,'status':'manifest/provenance regeneration check passed; not outcome scoring'}))

if __name__=='__main__':main()
