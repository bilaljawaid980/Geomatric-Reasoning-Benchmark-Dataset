"""Recipient-side checkpoint download; never used by the runner or Phase B builder."""
import argparse,json
from pathlib import Path
from workflow import CHECKPOINTS
def main():
    from huggingface_hub import HfApi,snapshot_download
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--record',type=Path,required=True);a=p.parse_args()
    if a.record.exists():raise FileExistsError('Checkpoints already fixed; keep this revision record and downloaded snapshots')
    revisions={}
    for model,repo in CHECKPOINTS.items():
        revision=HfApi().model_info(repo).sha
        snapshot_download(repo_id=repo,revision=revision,local_dir=a.output_dir/model)
        revisions[model]={'repository':repo,'revision':revision,'local_directory':model}
    a.record.parent.mkdir(parents=True,exist_ok=True)
    a.record.write_text(json.dumps(revisions,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
