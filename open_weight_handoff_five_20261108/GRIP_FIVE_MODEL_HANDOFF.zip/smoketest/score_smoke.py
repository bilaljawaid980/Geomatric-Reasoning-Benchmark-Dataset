"""The only answer-reading tool besides build_phase_b.py; smoke items only."""
import argparse,json,sys
from collections import defaultdict
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from build_phase_b import validate_pins

def main():
    config,_=validate_pins()
    sys.path.insert(0,str(ROOT/'scoring/vendor'))
    from analysis.typed_comparator import typed_comparator as T
    from analysis.tolerance_reanalysis_20261107 import tolerance_scoring as N
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--responses',type=Path,required=True);p.add_argument('--model',required=True);a=p.parse_args()
    answers=[json.loads(x) for x in (ROOT/'private/smoke_answers.jsonl').read_text(encoding='utf-8').splitlines() if x]
    raw=[json.loads(x) for x in a.responses.read_text(encoding='utf-8').splitlines() if x]
    by={r['row_id']:r for r in raw}
    if len(by)!=len(raw) or set(by)!={r['row_id'] for r in answers}:raise ValueError('Missing, extra or duplicate smoke response IDs')
    totals=defaultdict(lambda:[0,0,0])
    for row in answers:
        returned=by[row['row_id']]
        if returned['model']!=a.model:raise ValueError('Wrong model')
        kind,schema,_=T.OVERRIDES.get((row['domain'],int(row['level'])),('SCALAR','existing_exact',''))
        verdict=N.compare(returned['response_raw'],row,{'answer_type':kind,'schema_id':schema},returned.get('error'),enabled=config['smoke']['enabled'])
        d=totals[row['domain']];d[0]+=int(verdict.correct);d[1]+=1;d[2]+=int(verdict.parse_ok)
    for domain,(n,total,parsed) in sorted(totals.items()):print(json.dumps({'domain':domain,'correct':n,'items':total,'accuracy':n/total,'parse_rate':parsed/total}))
    print('Smoke diagnostics only. Do not score evaluation Round-2 responses; return them centrally.')

if __name__=='__main__':main()
