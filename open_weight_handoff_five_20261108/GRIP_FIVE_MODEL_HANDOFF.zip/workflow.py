"""Answer-free run configuration, progress and complete return packaging helpers."""
import argparse,csv,hashlib,json,subprocess,sys,zipfile
from pathlib import Path
from datetime import datetime,timezone
from verify import assert_public,check,verify_integrity
ROOT=Path(__file__).resolve().parent
CHECKPOINTS={
 'Qwen3-VL-8B-Instruct':'Qwen/Qwen3-VL-8B-Instruct',
 'Qwen3-VL-8B-Thinking':'Qwen/Qwen3-VL-8B-Thinking',
 'Molmo2-8B':'allenai/Molmo2-8B',
 'InternVL3.5-8B':'OpenGVLab/InternVL3_5-8B',
 'DeepSeek-VL2-Small':'deepseek-ai/deepseek-vl2-small'}
def dump(p,v):
    assert_public(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def main():
    # Same OS file-open guard as inference; this helper cannot read answers either.
    from run_local import install_private_guard,good
    install_private_guard(ROOT)
    p=argparse.ArgumentParser(description=__doc__);subs=p.add_subparsers(dest='command',required=True)
    q=subs.add_parser('init-config');q.add_argument('--model',choices=CHECKPOINTS,required=True);q.add_argument('--output',type=Path,required=True)
    q=subs.add_parser('approve');q.add_argument('--config',type=Path,required=True);q.add_argument('--approval-note',required=True)
    q=subs.add_parser('progress');q.add_argument('--output',type=Path,required=True)
    q=subs.add_parser('verify-return');q.add_argument('--work-dir',type=Path,required=True)
    q=subs.add_parser('pack-return');q.add_argument('--work-dir',type=Path,required=True);q.add_argument('--output',type=Path,required=True)
    a=p.parse_args();inventory=verify_integrity(ROOT)
    if a.command=='init-config':
        assert_public(a.output)
        if a.output.exists():raise FileExistsError('Keep resolved configurations; do not overwrite')
        c=json.loads((ROOT/'config.json').read_text())
        c.update(target_model=a.model,model_server_ids={m:m for m in CHECKPOINTS},temperature=0.0,top_p=1.0,max_tokens=8192 if a.model.endswith('Thinking') else 2048,centrally_approved=True,full_run_approval=None,
                 decoding_status='Proposed smoke recipe only, NOT a reconstruction of historical open-weight settings; full run requires owner approval.',checkpoint=CHECKPOINTS[a.model])
        dump(a.output,c);print('Smoke configuration created. Full evaluation remains blocked pending owner approval.');return
    if a.command=='approve':
        assert_public(a.config);c=json.loads(a.config.read_text())
        if not a.approval_note.strip() or 'REPLACE' in a.approval_note:raise ValueError('Record the real approval received; do not self-approve or use placeholder text')
        c['full_run_approval']={'note':a.approval_note,'recorded_at':datetime.now(timezone.utc).isoformat()}
        dump(a.config,c);print('Recorded approval. No decoding or request setting changed.');return
    if a.command=='progress':
        assert_public(a.output);cache=a.output.parent/('.progress_'+a.output.name)
        records=[json.loads(f.read_text()) for f in cache.glob('*.json') if f.name!='run.json']
        print(json.dumps({'cached_rows':len(records),'usable_cached_rows':sum(good(r) for r in records),'retry_on_resume':sum(not good(r) for r in records),'final_jsonl_exists':a.output.exists()},indent=2));return
    work=assert_public(a.work_dir);reports={};expected_files=[]
    for model in CHECKPOINTS:
        for exp,phase,manifest in [('SMOKE','',ROOT/'smoketest/manifest.csv'),('E3','A',ROOT/'evaluation/E3_phase_a.csv'),('E4','A',ROOT/'evaluation/E4_phase_a.csv'),('E3','B',work/'phase_b'/f'{model}_E3_phase_b.csv'),('E4','B',work/'phase_b'/f'{model}_E4_phase_b.csv')]:
            label=exp+('_'+phase if phase else '');raw=work/'responses'/f'{model}_{label}.jsonl'
            expected=inventory['expected_rows_per_model'][model][exp]
            if phase=='B':
                sidecar=manifest.with_suffix('.integrity.json');assert_public(sidecar)
                bi=json.loads(sidecar.read_text())
                if bi['model']!=model or bi['experiment']!=exp or hashlib.sha256(manifest.read_bytes()).hexdigest()!=bi['sha256']:raise ValueError('Phase B identity/hash mismatch')
                expected=bi['export_rows'];expected_files.extend([manifest,sidecar])
            report=check(manifest,raw,model,expected);reports[f'{model}:{label}']=report
            expected_files.append(raw)
        expected_files.extend([work/'configs'/f'{model}.json',work/'smoke'/f'{model}_scores.txt'])
    provenance=work/'phase_b/phase_b_provenance.json';assert_public(provenance)
    prov=json.loads(provenance.read_text())
    if len(prov['runs'])!=10:raise ValueError('Expected ten model/experiment provenance runs')
    for model in CHECKPOINTS:
        for exp in ['E3','E4']:
            filename=f'{model}_{exp}_phase_b.csv'
            matching=[r for r in prov['runs'].values() if r['manifest_filename']==filename]
            if len(matching)!=1 or matching[0]['manifest_sha256']!=hashlib.sha256((work/'phase_b'/filename).read_bytes()).hexdigest():raise ValueError('Provenance/manifest mismatch')
    for name,field in [('construction_scorer','scorer_sha256'),('tolerance_configuration','config_sha256'),('dependency_input_pins','pins_sha256')]:
        if prov[field]!=inventory[name]['sha256']:raise ValueError('Provenance pin mismatch')
    expected_files.extend([provenance,work/'environment.txt',work/'server_environment.txt',work/'hardware.txt',work/'checkpoint_revisions.json'])
    for f in expected_files:
        assert_public(f)
        if not f.is_file() or not f.stat().st_size:raise ValueError('Missing/empty return evidence: '+f.name)
    result={'complete':all(r['complete'] for r in reports.values()),'runs':reports,'provenance_runs':len(prov['runs']),'note':'Completeness only; final outcomes are scored centrally across fifteen models.'}
    report_path=work/'verify_output.json';dump(report_path,result);print(json.dumps(result,indent=2))
    if not result['complete']:raise SystemExit(2)
    if a.command=='pack-return':
        assert_public(a.output);expected_files.append(report_path)
        # Explicit allowlist: no package answers, checkpoints, cache, .env or logs.
        with zipfile.ZipFile(a.output,'x',compression=zipfile.ZIP_DEFLATED) as z:
            for f in sorted(set(expected_files)):z.write(f,f.relative_to(work).as_posix())
        print('Return ZIP created: '+a.output.name)
if __name__=='__main__':main()
