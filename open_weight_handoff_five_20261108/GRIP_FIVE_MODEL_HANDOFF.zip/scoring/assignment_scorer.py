"""Pinned adapter to the exact historical hosted arm-construction scorers.

This adapter does not evaluate Round 2 or produce experiment result tables.
The historical E3 strict policy is deliberately NOT the later tolerance reanalysis.
"""
from __future__ import annotations
import importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];VENDOR=ROOT/'scoring/vendor'
sys.dont_write_bytecode=True
sys.path[:0]=[str(VENDOR),str(VENDOR/'tests/test_1_closed_loop/scripts'),str(VENDOR/'tests/test_4_crossexam/scripts')]
import pandas as pd
from score_closed_loop import parse_and_compare
from crossexam_common import response_parts,answer_is_accepted,parse_claim_string

def load_module(rel,name):
    p=VENDOR/rel;spec=importlib.util.spec_from_file_location(name,p)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

E3=load_module('tests/test_3_sycophancy/scripts/build_sycophancy_manifest.py','pinned_e3_construction')
E4=load_module('tests/test_4_crossexam/scripts/build_crossexam_round2.py','pinned_e4_construction')
if not Path(parse_and_compare.__code__.co_filename).resolve().is_relative_to(VENDOR) or not Path(answer_is_accepted.__code__.co_filename).resolve().is_relative_to(VENDOR):
    raise RuntimeError('Scorer import escaped the pinned vendor tree')

def score_round1(experiment,inputs,config):
    if config['policy_id']!='historical-panels-approved-comparator-v2':raise ValueError('Unsupported pinned construction policy')
    if experiment=='E3':
        if config['E3']['comparator']!='exact copied legacy parse_and_compare':raise ValueError('E3 policy drift')
        return parse_and_compare(pd.DataFrame(inputs)).to_dict('records')
    if experiment!='E4':raise ValueError('Unknown experiment')
    if not config['E4'].get('construction_authorized',False):raise RuntimeError('E4 construction is not authorized by the pinned configuration; no override is supported')
    if config['E4']['comparator']!='exact copied response_parts + answer_is_accepted':raise ValueError('E4 policy drift')
    output=[]
    for source in inputs:
        row=dict(source);parts=response_parts(row['response_raw'])
        row['parse_ok']=not row.get('error') and parts['parse_ok'] and set(parse_claim_string(parts['answer'] or ''))==set(parse_claim_string(row['ground_truth']))
        row['absolute_correct']=not row.get('error') and answer_is_accepted(parts['answer'],row['acceptance_set'])
        row['parsed_parts']=parts;output.append(row)
    return output
