"""Score only the labelled, disjoint smoke data with the existing central comparators."""
import argparse,json,sys
from collections import defaultdict
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
from analysis.typed_comparator import typed_comparator as T
from analysis.tolerance_reanalysis_20261107 import tolerance_scoring as N

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--responses',type=Path,required=True);p.add_argument('--model',required=True);a=p.parse_args()
    if not (HERE/'answers.jsonl').is_file():raise FileNotFoundError('The fresh labelled smoke set is not available')
    answers=[json.loads(x) for x in (HERE/'answers.jsonl').read_text(encoding='utf-8').splitlines() if x]
    raw=[json.loads(x) for x in a.responses.read_text(encoding='utf-8').splitlines() if x]
    by={r['row_id']:r for r in raw}
    if len(by)!=len(raw) or set(by)!={r['row_id'] for r in answers}:raise ValueError('Missing, extra or duplicate smoke response IDs')
    totals=defaultdict(lambda:[0,0,0])
    for row in answers:
        returned=by[row['row_id']]
        if returned['model']!=a.model:raise ValueError('Wrong model')
        kind,schema,_=T.OVERRIDES.get((row['domain'],int(row['level'])),('SCALAR','existing_exact',''))
        spec={'answer_type':kind,'schema_id':schema}
        verdict=N.compare(returned['response_raw'],row,spec,returned.get('error'),enabled=True)
        d=totals[row['domain']];d[0]+=int(verdict.correct);d[1]+=1;d[2]+=int(verdict.parse_ok)
    for domain,(n,total,parsed) in sorted(totals.items()):print(json.dumps({'domain':domain,'correct':n,'items':total,'accuracy':n/total,'parse_rate':parsed/total}))
    print('Smoke only. Evaluation responses are evaluated centrally; local evaluation scoring will be discarded.')

if __name__=='__main__':main()
