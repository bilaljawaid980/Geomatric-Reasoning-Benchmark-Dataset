# GRIP: open-weight E3/E4 inference handoff

Run `smoketest/` first and confirm the per-domain numbers look sane. Then run
`evaluation/` and return raw responses without evaluating them. We evaluate all
sixteen models centrally with one comparator. Any local evaluation scoring will
be discarded. Only raw text is needed.

Read `STATUS.json` before using this bundle. A blocked smoke domain is a real
limitation, not a zero-accuracy result. Do not claim a complete 34-domain smoke
test when `smoketest/STATUS.json` lists unavailable domains.

## Contents and separation

- `evaluation/`: exact stored hosted PNG bytes and public prompts only. No labels.
- `smoketest/`: fresh, disjoint synthetic images, their full annotations/answers,
  the existing central comparators, and hosted domain reference points.
- `run_local.py`, `verify.py`: answer-free runner and completeness checks.
- `config.json`: configuration template and recorded hosted defaults.
- `INTEGRITY.json`: every shipped file's byte count and SHA-256, excluding itself.
  The sender supplies its SHA-256 separately. Expected Phase A counts per model:
  E3 **3,400** rows; E4 **2,000** rows. Six models make 32,400 Phase A requests.

Do not move smoke answers into evaluation. Never add labels to returned records.
The smoke/evaluation sets share neither image IDs nor question IDs; see status.

## Setup and serving

Use Python 3.10+; the runner/verifier use only the standard library. The smoke
comparators additionally need `numpy` and `pandas` (versions must be recorded).
Install these from your approved offline environment/wheelhouse when available:

```sh
python -m pip install numpy pandas
python -B verify.py --integrity-only
```

Obtain the approved checkpoint snapshots through your normal process. Do not
substitute larger/smaller or newer variants. Record exact checkpoint IDs and
revisions, serving engine/version, framework/CUDA/driver versions, GPU model/count,
dtype, quantisation (including none), image preprocessing configuration and the
resolved decoding parameters. Historical open-weight stack, hardware,
quantisation, decoding and runtime dates were **not recorded** in the archives.
There is no evidence-backed per-model engine/version recipe in this repository.

Serve one model at a time with a local OpenAI-compatible multimodal endpoint:
`http://127.0.0.1:8000/v1/chat/completions`. Required models and server names:

| Exact model | Suggested approved local directory | Served name |
| --- | --- | --- |
| Qwen3-VL-8B-Instruct | `/models/Qwen3-VL-8B-Instruct` | `Qwen3-VL-8B-Instruct` |
| Qwen3-VL-8B-Thinking | `/models/Qwen3-VL-8B-Thinking` | `Qwen3-VL-8B-Thinking` |
| Molmo2-8B | `/models/Molmo2-8B` | `Molmo2-8B` |
| InternVL3.5-8B | `/models/InternVL3.5-8B` | `InternVL3.5-8B` |
| Kimi-VL-A3B-Thinking | `/models/Kimi-VL-A3B-Thinking` | `Kimi-VL-A3B-Thinking` |
| DeepSeek-VL2-Small | `/models/DeepSeek-VL2-Small` | `DeepSeek-VL2-Small` |

For an installed engine that explicitly supports the exact checkpoint, a launch
template is `vllm serve /models/EXACT_MODEL --host 127.0.0.1 --port 8000
--served-model-name EXACT_MODEL`. This is a conditional example, **not** a verified
support/compatibility claim for these six architectures. If your engine does not
support one, use that checkpoint's approved adapter/server implementing the same
endpoint and image interface; do not silently substitute a text-only model or
different checkpoint. Confirm actual multimodal support with the labelled smoke
set. Engine-specific launch flags and resource estimates are not recorded here;
resolve and record them before evaluation, rather than guessing.

Make an external copy of `config.json` as `run_config.json` (outside the shipped
directory). Set `model_server_ids` to the server's exact names. Agree with the
central evaluator on `max_tokens`, temperature/top-p (null means omitted, **not**
temperature zero), any reasoning setting and any engine-specific generation
defaults. Set `centrally_approved: true` only after that agreement. The template
intentionally cannot start inference with unknown values. Do not edit the
integrity-protected template. Return your resolved config and environment record
separately, without credentials.

## What must stay fixed

No system message is inserted. Phase A has one user message, with original PNG
bytes in an image_url base64 data URI **before** the text. No runner resize, crop,
compression, image detail flag or image count change is permitted. Record any
unavoidable model/engine-internal processing; an adapter must not silently ignore
the image. `question_text` already contains the complete exact hosted user text,
including its response instruction. `answer_format_instruction` repeats only the
public suffix for inspection; the runner **does not append it again**.

All question text/whitespace and response-format wording are immutable. Both
thinking and non-thinking variants must preserve the server's final content
verbatim. No trimming, prefix stripping, parsing, rewriting, thinking-text joining
or answer-only extraction is allowed in `response_raw`. Separately returned API
reasoning fields are not concatenated into the content; record the server's
content/reasoning separation convention in your environment note. An endpoint
that does not provide one text `message.content` needs an approved adapter first.

Hosted runs used OpenRouter; per-model caps, reasoning options and routing hints
are recorded in `config.json` as current source defaults. Shared hosted requests
did not set temperature/top-p. Effective provider defaults, immutable resolved
versions and historical command-line overrides were not recorded. Do not claim
the open-weight runs match unrecorded hosted parameters.

## Smoke test, then Phase A

```sh
python -B run_local.py --manifest smoketest/manifest.csv --model Qwen3-VL-8B-Instruct --config ../run_config.json --output ../returns/Qwen3-VL-8B-Instruct_SMOKE.jsonl
python -B smoketest/score_smoke.py --responses ../returns/Qwen3-VL-8B-Instruct_SMOKE.jsonl --model Qwen3-VL-8B-Instruct
python -B run_local.py --manifest evaluation/E3_phase_a.csv --model Qwen3-VL-8B-Instruct --config ../run_config.json --output ../returns/Qwen3-VL-8B-Instruct_E3_A.jsonl
python -B run_local.py --manifest evaluation/E4_phase_a.csv --model Qwen3-VL-8B-Instruct --config ../run_config.json --output ../returns/Qwen3-VL-8B-Instruct_E4_A.jsonl
```

Repeat for each exact served model. Smoke images use requested indices 3001–3006,
or 1001–1006 for projectile_motion, outside the release. Unsupported generator
indices are reported, never filled using relabelled release scenes or substitute
seeds. `hosted_reference.csv` gives the minimum/maximum existing hosted E1
per-domain accuracy and the number of hosted models available. These are reference
points on a different sample under its original scoring path, **not** statistical
acceptance intervals, expected smoke accuracies, or targets to hit. Each complete
smoke domain has just 30 questions, so one error changes accuracy by 3.33 points.
An image-ignoring control or an independent visual inspection is useful if
several domains look implausible; accuracy alone cannot prove pipeline integrity.

No measured runtime on your hardware is available. Time the smoke pass, record
latency and memory locally and use that throughput for a rough schedule. E3/E4
have 5,400 Phase A requests per model, plus model-dependent Phase B requests.
Timeouts/retries, thinking generation and hardware can change that substantially.
No invented duration or GPU-memory estimate is supplied.

## Retry, resume and errors

The hosted outer policy is preserved: five additional retries (six total outer
attempts) for HTTP 429, HTTP >=500, connection failures or timeouts. Default request
timeout is 120 seconds. Delays are `1 * 2^(attempt-1)` seconds plus uniform jitter
between 0 and min(1 second, 10% of delay). Nontransient errors fail immediately.
Missing images make no server call. An empty successful reply is recorded empty,
not semantically retried inside that request. On a later resume, an error/empty or
literal none/null reply is retried; usable cached replies are skipped. Raw replies
are cached locally and exported exactly once per row at completion. Configuration,
prompt and own-R1 fingerprints prevent accidental resume across changed inputs.
The standard-library client has no hidden SDK retry layer; the original SDK's
internal retry settings were not recorded. Server-side retries are not controlled
by this runner and must be documented.

## Return schema and completeness

One UTF-8 JSONL per model per experiment/phase. Exactly these six fields:
`row_id, model, response_raw, error, finish_reason, timestamp`.
`error` and `finish_reason` are null or strings; timestamps are UTC ISO-8601.
Keep `response_raw` verbatim. Worked schema example (placeholder text, not a model
run or an evaluation answer):

```json
{"row_id":"E3:example:example_0000_q1","model":"Qwen3-VL-8B-Instruct","response_raw":"  ANSWER: <verbatim text>\n","error":null,"finish_reason":"stop","timestamp":"2026-11-08T00:00:00+00:00"}
```

```sh
python -B verify.py --manifest evaluation/E3_phase_a.csv --responses ../returns/Qwen3-VL-8B-Instruct_E3_A.jsonl --model Qwen3-VL-8B-Instruct --experiment E3 --return-zip ../returns/Qwen3-VL-8B-Instruct_E3_A.zip
```

Checks require one non-empty response per expected row, exactly one occurrence,
no extras, matching model/schema and no reported errors. They report ANSWER-label
extraction rate, truncation (`length`/`max_tokens`/`max_length` finish reasons),
unknown finish reasons and row counts against integrity. Extraction is a
label-presence diagnostic, not central typed parsing and not evidence of accuracy.
Resolve truncation and missing/errored rows with us before any changed-budget
rerun; do not silently change settings. A complete but truncated return is still
flagged in the report. The ZIP helper refuses incomplete files. Add your resolved
run config and environment note to the return, never the private progress cache.

## Phase B later

Send Phase A returns first. All answer-aware construction and arm assignment
happen centrally. You will receive a new manifest and integrity sidecar. Its CSV
contains exactly `row_id, model, image_path, prompt_text`; no hidden condition
labels are supplied. Asserted answers are only prose in `prompt_text`, not labels.
Natural E4 peers remain from the fixed original ten hosted models.

Keep your Phase A manifest and raw replies. The runner restores their exact user
and assistant history, then sends `prompt_text` as the second user message:

```sh
python -B run_local.py --manifest ../phase_b/E3_Qwen.csv --phase-b-integrity ../phase_b/E3_Qwen.integrity.json --round1-manifest evaluation/E3_phase_a.csv --round1-responses ../returns/Qwen3-VL-8B-Instruct_E3_A.jsonl --model Qwen3-VL-8B-Instruct --config ../run_config.json --output ../returns/Qwen3-VL-8B-Instruct_E3_B.jsonl
python -B verify.py --manifest ../phase_b/E3_Qwen.csv --phase-b-integrity ../phase_b/E3_Qwen.integrity.json --responses ../returns/Qwen3-VL-8B-Instruct_E3_B.jsonl --model Qwen3-VL-8B-Instruct --experiment E3 --return-zip ../returns/Qwen3-VL-8B-Instruct_E3_B.zip
```

Return raw Phase B responses too. Do not infer, compute or attach your own arm
labels or correctness. Do not run different models' first replies as history.
