"""Run explicit prompts against a loopback-only OpenAI-compatible image server."""
from __future__ import annotations
import argparse,base64,hashlib,json,random,socket,time,urllib.error,urllib.parse,urllib.request
from datetime import datetime,timezone
from pathlib import Path
from verify import read_manifest,verify_integrity

def utc():return datetime.now(timezone.utc).isoformat()

def good(r):
    return not r.get('error') and isinstance(r.get('response_raw'),str) and bool(r['response_raw'].strip()) and r['response_raw'].strip().casefold() not in {'none','null'}

def content(root,row):
    data_dir='smoketest' if row.get('experiment')=='SMOKE' else 'evaluation'
    image=(root/data_dir/row['image_path']).resolve()
    if not image.is_relative_to((root/data_dir/'images').resolve()):raise ValueError('Image path escapes bundle')
    data='data:image/png;base64,'+base64.b64encode(image.read_bytes()).decode('ascii')
    return [{'type':'image_url','image_url':{'url':data}}, {'type':'text','text':row['question_text']}]

def messages(root,row):
    if 'history' in row:
        # Phase B stores the exact original first user text separately.
        first=dict(row,question_text=row['history']['user_text'],answer_format_instruction='')
        c=content(root,first);c[1]['text']=row['history']['user_text']
        return [{'role':'user','content':c},{'role':'assistant','content':row['history']['assistant_text']},{'role':'user','content':row['question_text']}]
    return [{'role':'user','content':content(root,row)}]

def retryable(exc):
    if isinstance(exc,urllib.error.HTTPError):return exc.code==429 or exc.code>=500
    return isinstance(exc,(urllib.error.URLError,ConnectionError,TimeoutError,socket.timeout))

def issue(root,row,model,server_id,config,transport):
    result={'row_id':row['row_id'],'model':model,'response_raw':'','error':None,'finish_reason':None,'timestamp':utc()}
    try:
        body={'model':server_id,'messages':messages(root,row),'max_tokens':config['max_tokens']}
        for k in ['temperature','top_p','reasoning']:
            if config.get(k) is not None:body[k]=config[k]
    except FileNotFoundError:
        result['error']='FileNotFoundError: image not found';return result
    for attempt in range(1,int(config['additional_retries'])+2):
        try:
            payload=transport(body)
            choices=payload.get('choices') or []
            if choices:
                value=(choices[0].get('message') or {}).get('content')
                if value is None:value=''
                if not isinstance(value,str):raise TypeError('Server message.content must be one verbatim text string; no joining/coercion is performed')
                result['response_raw']=value
                result['finish_reason']=choices[0].get('finish_reason')
            result['timestamp']=utc();return result
        except Exception as exc:
            if retryable(exc) and attempt<=config['additional_retries']:
                delay=config['backoff_seconds']*2**(attempt-1)
                time.sleep(delay+random.uniform(0,min(1.,delay*.1)));continue
            # Avoid returning provider payloads which may contain local paths or secrets.
            result['error']=type(exc).__name__+(': HTTP '+str(exc.code) if isinstance(exc,urllib.error.HTTPError) else ': request failed')
            result['timestamp']=utc();return result
    raise AssertionError('retry loop')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,required=True);p.add_argument('--model',required=True)
    p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--round1-manifest',type=Path);p.add_argument('--round1-responses',type=Path)
    p.add_argument('--phase-b-integrity',type=Path)
    args=p.parse_args();root=Path(__file__).resolve().parent
    verify_integrity(root)
    c=json.loads(args.config.read_text(encoding='utf-8'))
    if args.model not in c['models']:raise ValueError('Unknown model')
    sid=c['model_server_ids'].get(args.model)
    if not sid or not isinstance(c.get('max_tokens'),int) or c['max_tokens']<1 or not c.get('centrally_approved',False):
        raise ValueError('Centrally approve a resolved run config, server model ID and max_tokens before inference')
    url=c['local_base_url'].rstrip('/')+'/chat/completions'
    parsed=urllib.parse.urlparse(url)
    if parsed.scheme not in {'http','https'} or parsed.hostname not in {'localhost','127.0.0.1','::1'} or parsed.username or parsed.password:
        raise ValueError('Only a credential-free loopback server URL is permitted')
    rows=read_manifest(args.manifest)
    if rows and 'prompt_text' in rows[0]:
        if not args.phase_b_integrity:raise ValueError('Phase B requires its centrally supplied integrity record')
        bi=json.loads(args.phase_b_integrity.read_text(encoding='utf-8'))
        if hashlib.sha256(args.manifest.read_bytes()).hexdigest()!=bi['sha256'] or bi['model']!=args.model:raise ValueError('Phase B integrity/model mismatch')
        if not args.round1_manifest or not args.round1_responses:raise ValueError('Phase B requires your existing Phase A manifest and raw return file')
        first={r['row_id']:r for r in read_manifest(args.round1_manifest)}
        previous={r['row_id']:r for r in read_manifest(args.round1_responses)}
        for r in rows:
            if set(r)!={'row_id','model','image_path','prompt_text'} or r['model']!=args.model:raise ValueError('Invalid Phase B schema/model')
            source_id=r['row_id'].rsplit(':',1)[0]
            original=first[source_id];prior=previous[source_id]
            if prior['model']!=args.model or not good(prior):raise ValueError('Missing usable own first reply')
            r['history']={'user_text':original['question_text'],'assistant_text':prior['response_raw']}
            r['question_text']=r['prompt_text']
    args.output.parent.mkdir(parents=True,exist_ok=True)
    cache=args.output.parent/('.progress_'+args.output.name);cache.mkdir(exist_ok=True)
    fingerprint=hashlib.sha256(json.dumps(c,sort_keys=True).encode()+args.manifest.read_bytes()+(args.round1_responses.read_bytes() if args.round1_responses else b'')).hexdigest()
    state=cache/'run.json'
    if state.exists() and json.loads(state.read_text())['fingerprint']!=fingerprint:raise ValueError('Config/manifest changed since start; use a new output path')
    state.write_text(json.dumps({'fingerprint':fingerprint}),encoding='utf-8')
    # No SDK means no hidden SDK retry layer. No redirects, credentials or proxies.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*unused):raise RuntimeError('Redirect prohibited')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    def transport(body):
        request=urllib.request.Request(url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'},method='POST')
        with opener.open(request,timeout=c['request_timeout_seconds']) as response:return json.load(response)
    results=[]
    for i,row in enumerate(rows,1):
        path=cache/(hashlib.sha256(row['row_id'].encode()).hexdigest()+'.json')
        old=json.loads(path.read_text(encoding='utf-8')) if path.exists() else None
        if old and old['row_id']==row['row_id'] and good(old):r=old
        else:
            r=issue(root,row,args.model,sid,c,transport)
            path.write_text(json.dumps(r,ensure_ascii=False)+'\n',encoding='utf-8')
        results.append(r)
        if i%25==0:print(f'{i}/{len(rows)}')
    # One row per manifest item, including exhausted errors. Never trim raw text.
    with args.output.open('w',encoding='utf-8',newline='\n') as f:
        for r in results:f.write(json.dumps(r,ensure_ascii=False)+'\n')
    print(str(args.output))

if __name__=='__main__':main()
