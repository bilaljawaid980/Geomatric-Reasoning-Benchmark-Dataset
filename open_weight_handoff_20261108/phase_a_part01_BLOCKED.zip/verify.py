"""Answer-free integrity and return-completeness validation. Standard library only."""
from __future__ import annotations
import argparse,csv,hashlib,json,re,zipfile
from datetime import datetime
from collections import Counter
from pathlib import Path
FIELDS=['row_id','model','response_raw','error','finish_reason','timestamp']

def read_manifest(path):
    if path.suffix=='.csv':
        with path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    else:rows=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
    if len({r['row_id'] for r in rows})!=len(rows):raise ValueError('Duplicate manifest IDs')
    return rows

def verify_integrity(root):
    data=json.loads((root/'INTEGRITY.json').read_text(encoding='utf-8'))
    known={x['path'] for x in data['files']}|{'INTEGRITY.json'}
    for rec in data['files']:
        p=(root/rec['path']).resolve()
        if not p.is_relative_to(root.resolve()) or not p.is_file():raise ValueError('Missing/unsafe package file: '+rec['path'])
        if p.stat().st_size!=rec['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=rec['sha256']:raise ValueError('Integrity mismatch: '+rec['path'])
    unexpected=[p.relative_to(root).as_posix() for p in (root/'evaluation').rglob('*') if p.is_file() and p.relative_to(root).as_posix() not in known]
    if unexpected:raise ValueError('Unlisted evaluation files: '+str(unexpected))
    return data

def check(manifest,output,model,expected):
    rows=read_manifest(manifest);ids={r['row_id'] for r in rows}; records=[]
    with output.open(encoding='utf-8') as f:
        for line in f:
            if line.strip():records.append(json.loads(line))
    counts=Counter(r.get('row_id') for r in records)
    bad_schema=sum(set(r)!=set(FIELDS) or not isinstance(r.get('response_raw'),str) or r.get('model')!=model or not isinstance(r.get('timestamp'),str) or not r.get('timestamp') or (r.get('error') is not None and not isinstance(r.get('error'),str)) or (r.get('finish_reason') is not None and not isinstance(r.get('finish_reason'),str)) for r in records)
    missing=ids-counts.keys();extra=counts.keys()-ids;dupes={k:v for k,v in counts.items() if v!=1}
    nonempty=sum(isinstance(r.get('response_raw'),str) and bool(r['response_raw'].strip()) and r['response_raw'].strip().casefold() not in {'none','null'} for r in records)
    for r in records:
        try:
            dt=datetime.fromisoformat(r.get('timestamp','').replace('Z','+00:00'))
            if dt.utcoffset() is None or dt.utcoffset().total_seconds()!=0:bad_schema+=1
        except (ValueError,TypeError,AttributeError):bad_schema+=1
    errors=sum(bool(r.get('error')) for r in records)
    extracted=sum(bool(re.search(r'^\s*(?:\*\*)?ANSWER(?:\*\*)?\s*:\s*\S',r.get('response_raw',''),re.M|re.I)) for r in records)
    trunc=sum(r.get('finish_reason') in {'length','max_tokens','max_length'} for r in records)
    unknown=sum(r.get('finish_reason') is None for r in records)
    result={'model':model,'manifest_rows':len(rows),'expected_rows':expected,'returned_rows':len(records),
        'missing_ids':len(missing),'extra_ids':len(extra),'duplicate_ids':len(dupes),'bad_schema_rows':bad_schema,
        'nonempty_responses':nonempty,'error_count':errors,'answer_label_extraction_count':extracted,
        'answer_label_extraction_rate':extracted/len(rows) if rows else 0,
        'truncation_count':trunc,'unknown_finish_reason_count':unknown,
        'extraction_note':'ANSWER label diagnostic only, not the central typed parser and not an accuracy metric'}
    result['complete']=len(rows)==expected==len(records)==nonempty and not (missing or extra or dupes or bad_schema or errors)
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--integrity-only',action='store_true');p.add_argument('--manifest',type=Path)
    p.add_argument('--responses',type=Path);p.add_argument('--model');p.add_argument('--experiment',choices=['E3','E4'])
    p.add_argument('--return-zip',type=Path)
    p.add_argument('--phase-b-integrity',type=Path)
    a=p.parse_args();root=Path(__file__).resolve().parent;data=verify_integrity(root)
    if a.integrity_only:print('Integrity verified');return
    if not all([a.manifest,a.responses,a.model,a.experiment]):p.error('manifest, responses, model, experiment required')
    expected=data['expected_rows_per_model'][a.model][a.experiment]
    if a.phase_b_integrity:
        bi=json.loads(a.phase_b_integrity.read_text(encoding='utf-8'))
        if hashlib.sha256(a.manifest.read_bytes()).hexdigest()!=bi['sha256'] or bi['model']!=a.model or bi['experiment']!=a.experiment:raise ValueError('Phase B identity/hash mismatch')
        expected=bi['export_rows']
    result=check(a.manifest,a.responses,a.model,expected);print(json.dumps(result,indent=2))
    if a.return_zip:
        if not result['complete']:raise ValueError('Cannot package an incomplete return')
        with zipfile.ZipFile(a.return_zip,'x',compression=zipfile.ZIP_DEFLATED) as z:
            z.write(a.responses,a.responses.name)
            z.writestr('completeness.json',json.dumps(result,indent=2))
            z.writestr('RUN_CONFIG_REQUIRED.txt','Include the resolved run config and serving environment/revision record with your return. Never include credentials.\n')
    if not result['complete']:raise SystemExit(2)

if __name__=='__main__':main()
